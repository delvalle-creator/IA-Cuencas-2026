# Grafos SNAP educativos - S1/S2 inundación Bahía Blanca

Estos grafos están preparados para que se vean ordenados en SNAP Graph Builder.
La sección `<applicationData id="Presentation">` posiciona los nodos en carriles compactos; por eso no deberían abrirse como ravioles con flechas cruzadas.

## Orden recomendado para la práctica

1. `00_S1_3FECHAS_SIGMA0_LINEAR_CGL30_RECOMENDADO_CLEAN.xml`  
   Flujo SAR recomendado: Orbit -> Calibration Sigma0 lineal -> Terrain Correction con Copernicus GLO-30 -> Collocate.

2. `01_S1_3FECHAS_INTENSITY_CGL30_COMMON_GRID_CLEAN.xml`  
   Variante para los recortes BEAM-DIMAP que ya traen `Intensity_VV` y `Intensity_VH`. No calibra; solo ortorrectifica/geocodifica con CGL30 y apila.

3. `02_S1S2_5FECHAS_INTENSITY_CGL30_COMMON_GRID_NO_SUBSET_CLEAN.xml`  
   Stack común S1+S2 sin recorte. Útil cuando todavía no se conoce el solapamiento.

4. `03_S1S2_5FECHAS_INTENSITY_CGL30_SUBSET_WKT_CLEAN.xml`  
   Stack común S1+S2 aplicando subset WKT antes del collocate.

5. `04_SUBSET_POST_COLLOCATE_WKT_CLEAN.xml`  
   Subset simple después de generar el producto collocated. Es el camino más seguro si primero se quiere inspeccionar el solape.

6. `05_DERIVADOS_S1S2_BANDMATHS_TEMPLATE_CLEAN.xml`  
   Calcula dVV, dVH, ratios same-track, MNDWI, dMNDWI, NDVI y dNDVI. Requiere los nombres de banda generados por los grafos 02/03.

## Advertencias docentes

- S1 03/03/2025 y 15/03/2025 comparten track 141: comparación radar estricta.
- S1 10/03/2025 es track 68: usar como diagnóstico visual, no como cambio radiométrico directo.
- Los productos `.dim` necesitan su carpeta `.data` al lado.
- Si un estudiante cambia los productos, debe revisar nombres de bandas antes de ejecutar BandMaths.
- Los grafos 02/03 no hacen BandMaths óptico; primero apilan, luego derivan. Así se evitan errores tipo `Undefined symbol B2`.

## Ejemplo de ejecución

```bash
gpt 03_S1S2_5FECHAS_INTENSITY_CGL30_SUBSET_WKT_CLEAN.xml \
  -p 03_S1S2_5FECHAS_INTENSITY_CGL30_SUBSET_WKT_CLEAN.properties \
  -c 16G -q 4 -x
```

## Layout

En Graph Builder los nodos se organizan así:

```text
S1 150325           S1 030325 master        S1 100325 diag
Read                Read                    Read
Orbit               Orbit                   Orbit
TC CGL30            TC CGL30                TC CGL30
Subset opcional     Subset opcional         Subset opcional
        \             |                    /
         Collocate 1503 -> 0303
                  |
         Collocate 1003 -> stack
                  |
          Collocate S2 pre/post
                  |
                 Write
```

El master se deja al centro para acortar los conectores.
