Vectores para SNAP/QGIS derivados del solapamiento común S1+S2 y de la máscara de sinergia.

Contenido:
- S1S2_overlap_common_UTM20S_EPSG32720: polígono del área común en CRS del raster (EPSG:32720).
- S1S2_overlap_common_WGS84_EPSG4326: el mismo polígono en lat/lon.
- S1S2_overlap_common_SIMPLIFIED_WGS84_EPSG4326: versión simplificada, liviana.
- S1S2_synergy_highConfidence_polygons_ge0p5ha_*: polígonos de candidatos de alta confianza >= 0.5 ha.
- S1S2_synergy_highConfidence_DISSOLVED_SIMPLIFIED_*: versión disuelta y simplificada para superposición rápida en SNAP.

Recomendación para SNAP:
1) Para recortar/subset: usar S1S2_overlap_common_UTM20S_EPSG32720.
2) Para superposición liviana: usar S1S2_synergy_highConfidence_DISSOLVED_SIMPLIFIED_UTM20S_EPSG32720.
3) Para edición o exportación cartográfica: usar las versiones WGS84 si tu proyecto está en lat/lon.

Nota: la máscara de alta confianza se basa en acuerdo radar+óptico, no es una verdad de campo.
