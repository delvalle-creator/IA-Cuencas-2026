SNAP RGB-ready package
======================

Estos GeoTIFF fueron reescritos para SNAP con:
- 3 bandas UInt8
- Photometric=RGB
- ColorInterp Red/Green/Blue
- Sin NoData=0, para que los negros reales no se oculten como nodata
- Nombres de bandas simples, sin espacios, sin ':' y sin '/', para evitar errores del parser de RGB/BandMaths.

En SNAP:
1) File > Open Product y abrir el .tif, o File > Import > Generic Formats > GeoTIFF.
2) Clic derecho sobre el producto > Open RGB Image Window.
3) Si aparecen los nombres simples, cargar el .rgb con el mismo nombre del TIFF.
4) Si SNAP lo importó como band_1, band_2, band_3, cargar el perfil *_band_1_band_2_band_3.rgb.
   Si SNAP lo importó como band1, band2, band3, cargar el perfil *_band1_band2_band3.rgb.

Archivos:
- S1_MT_VV_RGB_SNAP_READY.tif
  R_VV030325_pre_track141 / G_VV100325_post1_track68_DIAG / B_VV150325_post2_track141
- S1_MT_VH_RGB_SNAP_READY.tif
  R_VH030325_pre_track141 / G_VH100325_post1_track68_DIAG / B_VH150325_post2_track141
- S1_STRICT_sameTrack_RGB_SNAP_READY.tif
  R_logVV030325_pre_track141 / G_logVV150325_post2_track141 / B_dVVdrop030325_to_150325
- S1S2_SYNERGY_RGB_SNAP_READY.tif
  R_S1_radar_drop_score / G_S2_optical_change_score / B_S2_post_water_score
